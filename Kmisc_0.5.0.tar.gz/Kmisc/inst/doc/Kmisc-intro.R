
## @knitr , tidy=FALSE
set.seed(123)
library(Kmisc)
library(lattice)
library(grid)
dat <- data.frame( x=letters[1:4], y=1:4, z=LETTERS[1:4] )



## @knitr , tidy=FALSE
## let's remove columns 'x' and 'z' from dat.
dat[ !(names(dat) %in% c('x', 'z')) ]
## I always find that syntax awkward. Let's use Kmisc::without instead.
without( dat, x, z )
## finally, we can also index by $ (note: NOT done by partial matching):
without( dat, dat$x, dat$z )
## this could be handy for vectors with very long names, if using an IDE with
## auto-complete


## @knitr tidy=FALSE
extract( dat, x, y)


## @knitr tidy=FALSE
extract.re( dat, "[xy]")
without.re( dat, "[xy]")


## @knitr tidy=FALSE
tDat <- dat ## make a temporary copy of dat

## Replace some elements in tDat$y
tDat$y <- swap( tDat$y, from=c(2, 4), to=c(20, 40) )
cbind( dat$y, tDat$y )


## @knitr tidy=FALSE
bDat <- data.frame( x=rnorm(10), y=sample(letters,10), z=sample(letters,10) )
str( bDat )
str( factor_to_char(bDat) )


## @knitr , tidy=FALSE

dat <- data.frame( x = rnorm(100), y = rnorm(100), z = rnorm(100) )
dapply( dat, summary )


## @knitr , tidy=FALSE
dat1 <- data.frame( id=5:1, x=c("a","a","b","b","b"), y=rnorm(5) )
dat2 <- data.frame( id=c(1, 2, 4), z=rnorm(3) )

## default merge changes id order
merge( dat1, dat2, by="id", all.x=TRUE )
## even the sort parameter can't save you
merge( dat1, dat2, by="id", all.x=TRUE, sort=TRUE )
# kMerge keeps it as is
kMerge( dat1, dat2, by="id" )


## @knitr tidy=FALSE
x <- runif(10); lo <- 0.5; hi <- 1
print( data.frame( x=x, inner=in_interval(x, lo, hi) ) )


## @knitr tidy=FALSE
dfs <- replicate(1E3, 
                 data.frame(x=rnorm(10), y=sample(letters,10), z=sample(LETTERS,10)),
                 simplify=FALSE
                 )
str( stack_list(dfs) )
system.time( stack_list(dfs) )
system.time( do.call(rbind, dfs) )


## @knitr tidy=FALSE
str_rev( c("ABC", "DEF", NA, paste(LETTERS, collapse="") ) )
str_rev2( c("はひふへほ", "abcdef") )


## @knitr tidy=FALSE
str_slice( c("ABCDEF", "GHIJKL", "MNOP", "QR"), 2 )
str_slice2( "ハッピー", 2 )


## @knitr , tidy=FALSE
str_sort("asnoighewgypfuiweb")


## @knitr , tidy=FALSE
dat <- data.frame( y=rnorm(100), x=sample(letters[1:5], 100, TRUE) )
tMean <- Rcpp_tapply_generator("return mean(x);")
with( dat, tMean(y, x) )
with( dat, tapply(y, x, mean) )


## @knitr , tidy=FALSE
aMean <- Rcpp_apply_generator("return mean(x);")
mat <- matrix( rnorm(100), nrow=10 )
aMean(mat, 2)
apply(mat, 2, mean)


## @knitr , tidy=FALSE
library(microbenchmark)
y <- rnorm(1000); x <- sample(letters[1:5], 1000, TRUE)
tapply(y, x, mean)
tapply_(y, x, mean)
microbenchmark(
  tapply(y, x, mean),
  tapply_(y, x, mean),
  tMean(y, x)
  )


## @knitr , tidy=FALSE
dat <- data.frame(
  id=LETTERS[1:5],
  x1=rnorm(5),
  x2=rnorm(5),
  x3=rnorm(5)
)
print(dat)
melt_(dat, id.vars="id")


## @knitr results='asis'
dat <- data.frame( apple=c('a', 'b', 'c'), banana=c(1, 2, 3) )
makeHTMLTable( dat, use.col.names=TRUE )


## @knitr results='asis', tidy=FALSE
x <- factor( rbinom(100, 2, 0.2) )
y <- factor( rbinom(100, 3, 0.3) )

p1t( kTable( x, top.left.cell="foo" ) )
pxt( kTable(x, y, 
            top.left.cell="foo", 
            top.label="bar", 
            left.label="baz" 
            ) )



## @knitr results='asis', tidy=FALSE
html(
     table( class="my-favourite-table",
            tr(
              td("Apples"),
              td("Bananas")
              ),
            tr(
              td("20"),
              td("30")
              )
            )
     )


