#define USE_RINTERNALS

#include <R.h>
#include <Rinternals.h>

SEXP any_na( SEXP x ) {
	SEXP out;
	PROTECT(out = allocVector(LGLSXP, 1));
	int len = length(x);
	switch( TYPEOF(x) ) {
	case REALSXP: {
		double* ptr = REAL(x);
		for( int i=0; i < len; ++i ) {
			if( ISNA( ptr[i] ) || ISNAN( ptr[i] ) ) {
				LOGICAL(out)[0] = TRUE;
				UNPROTECT(1);
				return out;
			}
		}
		LOGICAL(out)[0] = FALSE;
		UNPROTECT(1);
		return out;
	}
	case INTSXP: {
		int* ptr = INTEGER(x);
		for( int i=0; i < len; ++i ) {
			if( ptr[i] == NA_INTEGER ) {
				LOGICAL(out)[0] = TRUE;
				UNPROTECT(1);
				return out;
			}
		}
		LOGICAL(out)[0] = FALSE;
		UNPROTECT(1);
		return out;
	}
	case LGLSXP: {
		int* ptr = LOGICAL(x);
		for( int i=0; i < len; ++i ) {
			if( ptr[i] == NA_LOGICAL ) {
				LOGICAL(out)[0] = TRUE;
				UNPROTECT(1);
				return out;
			}
		}
		LOGICAL(out)[0] = FALSE;
		UNPROTECT(1);
		return out;
	}
	case STRSXP: {
		for( int i=0; i < len; ++i ) {
			if( STRING_ELT(x, i) == NA_STRING ) {
				LOGICAL(out)[0] = TRUE;
				UNPROTECT(1);
				return out;
			}
		}
		LOGICAL(out)[0] = FALSE;
		UNPROTECT(1);
		return out;
	}
	}
	error("argument is of incompatible type '%s'", type2char( TYPEOF(x) ) );
	return x;
}

#undef USE_RINTERNALS

#define USE_RINTERNALS

#include <R.h>
#include <Rinternals.h>

SEXP charlist_transpose_to_df( SEXP x ) {
  
  if( TYPEOF(x) != VECSXP ) {
    error("argument must be a list; type is '%s'", type2char( TYPEOF(x)));
  }

	int out_nRow = length(x);
	int out_nCol = length( VECTOR_ELT(x, 0) );

	SEXP out = PROTECT( allocVector( VECSXP, out_nCol ) );

	for( int j=0; j < out_nCol; ++j ) {
		SEXP tmp = PROTECT( allocVector( STRSXP, out_nRow ) );
		for( int i=0; i < out_nRow; ++i ) {
			SET_STRING_ELT( tmp, i, STRING_ELT( VECTOR_ELT( x, i ), j ) );
		}
		SET_VECTOR_ELT( out, j, tmp );
		UNPROTECT(1);
	}

	SEXP row_names = PROTECT( allocVector( INTSXP, out_nRow ) );
	int* row_names_ptr = INTEGER(row_names);
	for( int i=0; i < out_nRow; ++i )
		row_names_ptr[i] = i+1;

	setAttrib(out, R_ClassSymbol, mkString("data.frame"));
	setAttrib(out, R_RowNamesSymbol, row_names);

	UNPROTECT(2);
	return out;
}

#undef USE_RINTERNALS

#define USE_RINTERNALS

#include <R.h>
#include <Rinternals.h>

SEXP recurse_factor_to_char( SEXP X, SEXP parent, int i ) {

  if( TYPEOF(X) == VECSXP ) {
    for( int j=0; j < length(X); ++j ) {
      recurse_factor_to_char( VECTOR_ELT(X, j), X, j );
    }
  } else {
    if( isFactor(X) ) {
      SET_VECTOR_ELT( parent, i, asCharacterFactor(X) );
    }
  }
  return X;

}

SEXP factor_to_char( SEXP X_ ) {
  SEXP X;
  PROTECT( X = duplicate(X_) );
  if( TYPEOF(X) == VECSXP ) {
    SEXP out = recurse_factor_to_char( X, X, 0);
    UNPROTECT(1);
    return out;
  } else {
    if( isFactor(X) ) {
      SEXP out = asCharacterFactor(X);
      UNPROTECT(1);
      return out;
    } else {
      warning("X is neither a list nor a factor; no change done");
      UNPROTECT(1);
      return X;
    }
  }
}

#undef USE_RINTERNALS

#define USE_RINTERNALS

#include <R.h>
#include <Rinternals.h>

SEXP in_interval( SEXP x, SEXP lo, SEXP hi, 
        SEXP include_lower, SEXP include_upper ) {
  
  int len = Rf_length(x);
  double lower = REAL(lo)[0], upper = REAL(hi)[0], *xp = REAL(x);
  
  int inc_lower = asLogical(include_lower);
  int inc_upper = asLogical(include_upper);
  
  SEXP out = PROTECT( allocVector( LGLSXP, len ) );
  int *outp = LOGICAL(out);
  
  if( inc_lower == 1 && inc_upper == 1 ) {
      for( int i=0; i < len; ++i ) {
        outp[i] = xp[i] >= lower && xp[i] <= upper;
        }
  }
  
  if( inc_lower == 1 && inc_upper == 0 ) {
      for( int i=0; i < len; ++i ) {
        outp[i] = xp[i] >= lower && xp[i] < upper;
        }
  }
  
  if( inc_lower == 0 && inc_upper == 1 ) {
      for( int i=0; i < len; ++i ) {
        outp[i] = xp[i] > lower && xp[i] <= upper;
        }
  }
  
  if( inc_lower == 0 && inc_upper == 0 ) {
      for( int i=0; i < len; ++i ) {
        outp[i] = xp[i] > lower && xp[i] < upper;
        }
  }
  
  UNPROTECT(1);
  return out;
  
}

#undef USE_RINTERNALS

#define USE_RINTERNALS

#include <R.h>
#include <Rinternals.h>
#include <stdlib.h>

SEXP list_to_dataframe(SEXP x_, SEXP inplace) {

	SEXP x;
	int unprotect_num = 1;

	if (TYPEOF(inplace) != LGLSXP || length(inplace) > 1) {
		error("'inplace' must be a logical vector of length 1; type is '%s'",
		type2char(TYPEOF(inplace)));
	}

	if (LOGICAL(inplace)[0] < 0) {
		error("'inplace' must be non-NA");
	}

	if (TYPEOF(x_) != VECSXP)
		error("argument must be a list; type is '%s'", type2char(TYPEOF(x_)));

	if (LOGICAL(inplace)[0]) {
		x = x_;
	} else {
		x = PROTECT( duplicate(x_) );
		++unprotect_num;
	}

	int m = length(x);
	int n = length( VECTOR_ELT(x, 0) );
	for (int i = 1; i < m; ++i) {
		if (length( VECTOR_ELT(x, i) ) != n) {
			error("not all columns are of equal length");
		}
	}

	SEXP row_names = PROTECT( allocVector( INTSXP, n ) );
	for (int i = 0; i < n; ++i)
		INTEGER(row_names)[i] = i + 1;

	setAttrib(x, R_ClassSymbol, mkString("data.frame"));
	setAttrib(x, R_RowNamesSymbol, row_names);

	// set the names, if NULL
	if (isNull( getAttrib(x, R_NamesSymbol) )) {
		SEXP colnames;
		PROTECT(colnames = allocVector(STRSXP, m));
		++unprotect_num;
		char* str;
		for (int i = 0; i < m; ++i) {
			asprintf(&str, "%s%i", "V", i + 1);
			SET_STRING_ELT(colnames, i, mkChar(str));
		}
		setAttrib(x, R_NamesSymbol, colnames);

	}

	UNPROTECT(unprotect_num);
	return x;

}

#undef USE_RINTERNALS

#define USE_RINTERNALS

#include <R.h>
#include <Rinternals.h>

SEXP rep_each_char( SEXP x, int each ) {

	SEXP out;
	int len = length(x);
	PROTECT( out = allocVector( STRSXP, len*each ) );
	int counter=0;
	SEXP* ptr = STRING_PTR(x);
	SEXP* out_ptr = STRING_PTR(out);
	for( int i=0; i < len; ++i ) {
		for( int j=0; j < each; ++j ) {
			out_ptr[counter] = ptr[i];
			//SET_STRING_ELT( out, counter, ptr[i] );
			++counter;
		}
	}
	UNPROTECT(1);
	return out;
}

#define HANDLE_CASE( RTYPE, CTYPE, ACCESSOR ) \
		case RTYPE: { \
			PROTECT( out = allocVector( RTYPE, len*times ) ); \
			CTYPE* ptr = ACCESSOR(x); \
			CTYPE* out_ptr = ACCESSOR(out); \
			for( int i=0; i < times; ++i ) { \
				for( int j=0; j < len; ++j ) { \
					out_ptr[counter] = ptr[j]; \
					++counter; \
				} \
			} \
			UNPROTECT(1); \
			return out; \
		} \

SEXP stack_vector( SEXP x, int times ) {
	SEXP out;
	int len = length(x);
	int counter = 0;
	switch( TYPEOF(x) ) {
	HANDLE_CASE( INTSXP, int, INTEGER );
	HANDLE_CASE( REALSXP, double, REAL );
	HANDLE_CASE( LGLSXP, int, LOGICAL );
	HANDLE_CASE( STRSXP, SEXP, STRING_PTR );
	}
  
  // if we've reached here, we have an unhandled / incompatible SEXP type
	error("argument is of incompatible type '%s'", type2char(TYPEOF(x)));
	return R_NilValue;
}

#undef HANDLE_CASE

SEXP melt_dataframe( SEXP x_stack, SEXP x_rep, SEXP variable_name, SEXP value_name ) {

	int nColStack = length(x_stack);
	int nColRep = length(x_rep);
	int nRow = length( VECTOR_ELT(x_stack, 0) );
	int out_nRow = nRow * nColRep;
	int out_nCol = nColStack + 2;

	SEXP out;
	PROTECT( out = allocVector( VECSXP, out_nCol ) );

	// populate the value array
	SEXP value_SEXP;

#define HANDLE_CASE( RTYPE, CTYPE, ACCESSOR ) \
		case RTYPE: { \
			PROTECT( value_SEXP = allocVector( RTYPE, value_len ) ); \
			int counter = 0; \
			CTYPE* ptr_val = ACCESSOR( value_SEXP ); \
			for( int i=0; i < nColRep; ++i ) { \
				CTYPE* ptr = ACCESSOR( VECTOR_ELT( x_rep, i ) ); \
				for( int j=0; j < nRow; ++j ) { \
					ptr_val[counter] = ptr[j]; \
					++counter; \
				} \
			} \
			break; \
		} \


	int value_len = nColRep * nRow;
	int value_type = TYPEOF( VECTOR_ELT( x_rep, 0 ) );
	switch( value_type ) {
	HANDLE_CASE( INTSXP, int, INTEGER );
	HANDLE_CASE( REALSXP, double, REAL );
	HANDLE_CASE( LGLSXP, int, LOGICAL );
	case STRSXP: {
		int counter = 0;
		PROTECT( value_SEXP = allocVector( STRSXP, value_len ) );
		for( int i=0; i < nColRep; ++i ) {
			SEXP curr_str_vec = VECTOR_ELT( x_rep, i );
			SEXP* value_SEXP_ptr = STRING_PTR( value_SEXP );
			SEXP* curr_str_vec_ptr = STRING_PTR(curr_str_vec);
			for( int j=0; j < nRow; ++j ) {
				value_SEXP_ptr[counter] = curr_str_vec_ptr[j];
				//SET_STRING_ELT( value_SEXP, counter, STRING_ELT( curr_str_vec, j ) );
				++counter;
			}
		}
		break;
	}
	default:
		error("Unsupported RTYPE encountered");
	}
  
#undef HANDLE_CASE

	// generate the id variables, and assign them on generation
	for( int i=0; i < nColStack; ++i ) {
		SET_VECTOR_ELT( out, i, stack_vector( VECTOR_ELT( x_stack, i ), nColRep ) );
	}

	// assign the names, values
	SET_VECTOR_ELT( out, nColStack, rep_each_char( getAttrib( x_rep, R_NamesSymbol ), nRow ) );
	SET_VECTOR_ELT( out, nColStack+1, value_SEXP );
	UNPROTECT(1); // value_SEXP

	// set the row names
	SEXP row_names;
	PROTECT( row_names = allocVector(INTSXP, out_nRow) );
	int* row_names_ptr = INTEGER(row_names);
	for( int i=0; i < out_nRow; ++i ) {
		row_names_ptr[i] = i+1;
	}
	setAttrib( out, R_RowNamesSymbol, row_names );
	UNPROTECT(1);

	// set the class to data.frame
	setAttrib( out, R_ClassSymbol, mkString("data.frame") );

	// set the names
	SEXP names = getAttrib( x_stack, R_NamesSymbol );
	SEXP names_out;
	PROTECT( names_out = allocVector( STRSXP, out_nCol ) );
	for( int i=0; i < nColStack; ++i ) {
		SET_STRING_ELT( names_out, i, STRING_ELT( names, i ) );
	}
	SET_STRING_ELT( names_out, nColStack, STRING_ELT(variable_name, 0) );
	SET_STRING_ELT( names_out, nColStack+1, STRING_ELT(value_name, 0) );
	setAttrib( out, R_NamesSymbol, names_out );
	UNPROTECT(1);

	UNPROTECT(1); // out
	return out;

}

#undef USE_RINTERNALS

#define USE_RINTERNALS

#include <R.h>
#include <Rinternals.h>

SEXP rep_row_names( SEXP x, int times ) {
	SEXP out;
	int len = length(x);
	int counter = 0;
	PROTECT( out = allocVector( STRSXP, len*times ) );
	SEXP* x_ptr = STRING_PTR(x);
	SEXP* out_ptr = STRING_PTR(out);
	for( int i=0; i < times; ++i ) {
		for( int j=0; j < len; ++j ) {
			out_ptr[counter] = x_ptr[j];
			//SET_STRING_ELT( out, counter, STRING_ELT(x, j) );
			++counter;
		}
	}
	UNPROTECT(1);
	return out;
}
SEXP rep_col_names( SEXP x, int each ) {
	SEXP out;
	int len = length(x);
	PROTECT( out = allocVector( STRSXP, len*each ) );
	int counter=0;
	SEXP* ptr = STRING_PTR(x);
	SEXP* out_ptr = STRING_PTR(out);
	for( int i=0; i < len; ++i ) {
		for( int j=0; j < each; j++ ) {
			out_ptr[counter] = ptr[i];
			//SET_STRING_ELT( out, counter, ptr[i] );
			++counter;
		}
	}
	UNPROTECT(1);
	return out;
}

SEXP matrix_to_vector( SEXP x, int size ) {

	SEXP out;
	switch( TYPEOF(x) ) {
	case INTSXP: {
		PROTECT( out = allocVector(INTSXP, size) );
		int* mat_ptr = INTEGER(x);
		int* out_ptr = INTEGER(out);
		for( int i=0; i < size; ++i ) {
			out_ptr[i] = mat_ptr[i];
		}
		UNPROTECT(1);
		return out;
	}
	case REALSXP: {
		PROTECT( out = allocVector(REALSXP, size) );
		double* mat_ptr = REAL(x);
		double* out_ptr = REAL(out);
		for( int i=0; i < size; ++i ) {
			out_ptr[i] = mat_ptr[i];
		}
		UNPROTECT(1);
		return out;
	}
	case LGLSXP: {
		PROTECT( out = allocVector(LGLSXP, size) );
		int* mat_ptr = LOGICAL(x);
		int* out_ptr = LOGICAL(out);
		for( int i=0; i < size; ++i ) {
			out_ptr[i] = mat_ptr[i];
		}
		UNPROTECT(1);
		return out;
	}
	case STRSXP: {
		PROTECT( out = allocVector( STRSXP, size ) );
		SEXP* mat_ptr = STRING_PTR(x);
		SEXP* out_ptr = STRING_PTR(out);
		for( int i=0; i < size; ++i ) {
			out_ptr[i] = mat_ptr[i];
		}
		UNPROTECT(1);
		return out;
	}
	default: {
		return R_NilValue;
	}
	}

}

SEXP melt_matrix( SEXP x ) {

	SEXP row, col, out, out_row_names;

	int nRow = nrows(x);
	int nCol = ncols(x);
	int out_nRow = nRow*nCol;
	int out_nCol = 3;

	// the output will be a 3 column data.frame
	// 1: repeated row names / indexes
	// 2: repeated col names / indexes
	// 3: values

	SEXP row_names, col_names;
	const char* row_names_char;
	const char* col_names_char;
	GetMatrixDimnames(x, &row_names, &col_names, &row_names_char, &col_names_char);

	PROTECT( out = allocVector( VECSXP, 3 ) );
	int counter;

	// row indices
	if( isNull(row_names) ) {
		PROTECT( row = allocVector( INTSXP, out_nRow ) );
		int* row_ptr = INTEGER(row);
		counter = 0;
		for( int i=0; i < nCol; ++i ) {
			for( int j=0; j < nRow; ++j ) {
				row_ptr[counter] = j+1;
				++counter;
			}
		}
	} else {
		PROTECT( row = rep_row_names(row_names, nCol) );
	}

	// col indices
	if( isNull(col_names) ) {
		PROTECT( col = allocVector( INTSXP, out_nRow ) );
		int* col_ptr = INTEGER(col);
		counter = 0;
		for( int i=0; i < nCol; ++i ) {
			for( int j=0; j < nRow; ++j ) {
				col_ptr[counter] = i+1;
				++counter;
			}
		}
	} else {
		PROTECT( col = rep_col_names(col_names, nRow) );
	}

	// dim_names is a list; 1st entry is row names, 2nd is col names
	SET_VECTOR_ELT( out, 0, row );
	SET_VECTOR_ELT( out, 1, col );
	SET_VECTOR_ELT( out, 2, matrix_to_vector(x, out_nRow) );

	// set row names
	PROTECT( out_row_names = allocVector( INTSXP, out_nRow) );
	int* row_names_ptr = INTEGER(out_row_names);
	for( int i=0; i < out_nRow; ++i ) {
		row_names_ptr[i] = i+1;
	}
	setAttrib( out, R_RowNamesSymbol, out_row_names );
	UNPROTECT(1);

	// set class
	setAttrib( out, R_ClassSymbol, mkString("data.frame") );

	// set names
	SEXP names;
	PROTECT( names = allocVector( STRSXP, out_nCol ) );
	SET_STRING_ELT( names, 0, mkChar("row") );
	SET_STRING_ELT( names, 1, mkChar("col") );
	SET_STRING_ELT( names, 2, mkChar("value") );
	setAttrib( out, R_NamesSymbol, names );
	UNPROTECT(1);

	// unprotect the rest of the stuff from earlier
	UNPROTECT(3);
	return out;

}

#undef USE_RINTERNALS

#define USE_RINTERNALS

#include <R.h>
#include <Rinternals.h>

SEXP simp( SEXP x, SEXP y ) {

	SEXP out;
	PROTECT( out = allocVector(REALSXP, 1) );

	int nx = length(x);
	int ny = length(y);

	if( nx != ny ) {
		Rf_error("'x' must be the same length as 'y'");
	}

	double out_num = 0;
	double mult = 1;

	for( int i=0; i < nx; ++i ) {

		// get the correct multiplier
		if( i == 0 ) {
			mult = 1.0;
		} else if( i == nx-1 ) {
			mult = 1.0;
		} else if( i % 2 == 1 ) {
			mult = 4.0;
		} else if( i % 2 == 0 ) {
			mult = 2.0;
		}

		out_num = out_num + (mult * REAL(y)[i]);
		// Rprintf("i = %i; REAL(y)[i] = %f; mult = %f; out_num = %f\n", i, REAL(y)[i], mult, out_num);
	}

	double h = (REAL(x)[nx-1] - REAL(x)[0]) / (double) nx;
	// Rprintf("h = %f\n", h);

	out_num = (h / 3.0) * out_num;
	// Rprintf("the final value of out_num is %f\n", out_num);

	REAL(out)[0] = out_num;
	UNPROTECT(1);
	return out;

}

#undef USE_RINTERNALS

#define USE_RINTERNALS

#include <R.h>
#include <Rdefines.h>

SEXP str_rev( SEXP x ) {
  
  int len = length(x);
  SEXP out;
  PROTECT( out = allocVector( STRSXP, len ) );
  
  // Loop through each string
  for( int i=0; i < len; ++i ) {
    
    // Get the current element of the string
    int len_elt = length( STRING_ELT(x, i) );
    const char* element = CHAR( STRING_ELT(x, i) );
    
    // Allocate space for the reversed string
    char* elt_rev = R_alloc( len_elt+1, sizeof(char) );
    
    // Reverse 'elt'
    for( int j=0; j < len_elt; ++j ) {
      elt_rev[j] = element[ len_elt - j - 1];
    }
    
    // Set the null terminator
    elt_rev[len_elt] = '\0';
    
    // Set the i'th element of out to the reversed char
    SET_STRING_ELT( out, i, mkChar( elt_rev ) );
    
  }
    
    UNPROTECT(1);
    return out;
}

#undef USE_RINTERNALS

#define USE_RINTERNALS

#include <R.h>
#include <Rdefines.h>

SEXP str_slice(SEXP x, SEXP n) {
    
    // Treat x as a vector of characters
    int x_len = length(x);
    int len_substr = INTEGER(n)[0];
    
    // Allocate memory for a list
    SEXP out;
    PROTECT( out = allocVector(VECSXP, x_len) );
    
    for( int k=0; k < x_len; ++k ) {
        
        // The string as a pointer to an array of characters
        const char* xx = CHAR(STRING_ELT( x, k ) );

        // The length of the string supplied
        int len = length( STRING_ELT( x, k ) );

        // The number of substrings
        int num_substr = len / len_substr;
        
        // Allocate memory for the vector of substrings
        SEXP substring;
        PROTECT( substring = allocVector(STRSXP, num_substr) );

        int string_counter = 0;
        for( int i=0; i < num_substr; ++i ) {

            // allocate memory for a string
            char* elt = R_alloc( len_substr+1, sizeof(char)  );

            // Push items onto the element
            for( int j=0; j < len_substr; ++j ) {
                elt[j] = xx[string_counter];
                string_counter++;
            }

            // Set the terminator
            elt[len_substr] = '\0';

            SET_STRING_ELT( substring, i, mkChar(elt) );
        }
        
        // Set the list element to the substring
        SET_VECTOR_ELT(out, k, substring);
        UNPROTECT(1);
        
    }
    
    UNPROTECT(1);
    return( out );
    
}

#undef USE_RINTERNALS

