#include <Rcpp.h>
#include <Rdefines.h>
using namespace Rcpp;

template <int RTYPE>
inline
IntegerVector do_counts( const Vector<RTYPE>& x ) {
  IntegerVector output = table(x);
  if( Rf_isFactor(x) ) {
    Rf_setAttrib(output, R_NamesSymbol, Rf_getAttrib(x, R_LevelsSymbol));
  }
  return output;
}

// [[Rcpp::export]]
SEXP counts( SEXP x ) {
  switch( TYPEOF(x) ) {
  case INTSXP: return do_counts<INTSXP>(x);
  case REALSXP: return do_counts<REALSXP>(x);
  case STRSXP: return do_counts<STRSXP>(x);
  case LGLSXP: return do_counts<LGLSXP>(x);
  default: {
    Rf_error("'x' is of invalid type '%s'", Rf_type2char( TYPEOF(x) ));
    return R_NilValue;
  }
  }
}

#include <iostream>
#include <fstream>
#include <Rcpp.h>
using namespace Rcpp;

std::string get_item( std::string& line, std::string& delim, int column ) {

	char* line_cast = const_cast<char*>( line.c_str() );
	const char* pch = strtok(line_cast, delim.c_str());
	int counter = 0;
	while( pch != NULL ) {
		if( counter == column-1 ) {
			return( std::string(pch) );
		}
		pch = strtok(NULL, delim.c_str());
		++counter;
	}
	stop( "get_line is broken" );
	return( "get_line is broken" );
}

inline bool in( std::string& item, std::vector< std::string >& list ) {

	if( std::find( list.begin(), list.end(), item ) != list.end() ) {
		return true;
	} else {
		return false;
	}
}

// [[Rcpp::export]]
void extract_rows_from_file_to_file(
		std::string input_file_name,
		std::string output_file_name,
		std::string delim,
		std::vector< std::string > items_to_keep,
		int column_to_check ) {

	std::string line;
	std::string line_copy;
	std::string item_to_check;

	std::ifstream conn( input_file_name.c_str(), std::ios_base::binary );
	std::ofstream out_conn( output_file_name.c_str() );
	std::ostreambuf_iterator<char> out_itr( out_conn );

	if( !out_conn.is_open() ) {
		stop("Couldn't open the output file!");
	}

	if( conn.is_open() ) {
		// Rcout << "Successfully opened file." << std::endl;
		while( std::getline(conn, line) ) {

			// copy the string
			line_copy = line.c_str();
			item_to_check = get_item( line_copy, delim, column_to_check );
			// Rcout << "The item we're checking is: " << item_to_check << std::endl;
			if( in( item_to_check, items_to_keep ) ) {
				// Rcout << "Copying line" << std::endl;
				std::copy( line.begin(), line.end(), out_itr );
				out_itr = '\n';
			}
		}
	} else {
		stop("Couldn't open File!\nInput file path: " + input_file_name);
	}

	conn.close();
	out_conn.close();

}

// [[Rcpp::export]]
std::vector<std::string> extract_rows_from_file(
		std::string input_file_name,
		std::string delim,
		std::vector< std::string > items_to_keep,
		int column_to_check ) {

	std::string line;
	std::string line_copy;
	std::string item_to_check;
	std::vector<std::string> output;

	std::ifstream conn( input_file_name.c_str(), std::ios_base::binary );

	if( conn.is_open() ) {
		// Rcout << "Successfully opened file." << std::endl;
		while( std::getline(conn, line) ) {

			// copy the string
			line_copy = line.c_str();
			item_to_check = get_item( line_copy, delim, column_to_check );
			// Rcout << "The item we're checking is: " << item_to_check << std::endl;
			if( in( item_to_check, items_to_keep ) ) {
				// Rcout << "Copying line" << std::endl;
				output.push_back(line);
			}
		}
	} else {
		stop("Couldn't open File!\nInput file path: " + input_file_name);
	}

	conn.close();
	return output;

}

#include <Rcpp.h>
using namespace Rcpp;

template <int RTYPE>
IntegerVector fast_factor_template( const Vector<RTYPE>& x ) {

	Vector<RTYPE> sorted = sort_unique(x);
	IntegerVector out = match( x, sorted );

	// handle NAs
	if( Vector<RTYPE>::is_na( *sorted.begin() ) ) {

		out = out - 1;
		// we replace all 0's with NAs in the output
		for( IntegerVector::iterator it = out.begin(); it != out.end(); ++it ) {
			if( (*it) == 0 ) {
				(*it) = NA_INTEGER;
			}
		}

		// we remove the first element from sorted, since it acts as levels
		Vector<RTYPE> levels( sorted.begin()+1, sorted.end() );
		out.attr("levels") = as<CharacterVector>( levels );

	} else {
		out.attr("levels") = as<CharacterVector>( sorted );
	}

	out.attr("class") = "factor";
	return out;

}

// [[Rcpp::export]]
SEXP fast_factor( SEXP x ) {
	int type = TYPEOF(x);
	switch( type ) {
	case INTSXP: return fast_factor_template<INTSXP>( x );
	case REALSXP: return fast_factor_template<REALSXP>( x );
	case STRSXP: return fast_factor_template<STRSXP>( x );
	case LGLSXP: return fast_factor_template<INTSXP>( x );
	}
	Rf_error("argument is of incompatible type '%s'", Rf_type2char( TYPEOF(x) ));
	return R_NilValue;
}

#include <Rcpp.h>
#include <iostream>
#include <fstream>
#include <string.h>

using namespace Rcpp;

std::string get_item( std::string& line, const char* delim, const int column ) {

	char* line_cast = const_cast<char*>( line.c_str() );
	const char* pch = strtok(line_cast, delim);
	int counter = 0;
	while( pch != NULL ) {
		if( counter == column-1 ) {
			return( std::string(pch) );
		}
		pch = strtok(NULL, delim);
		++counter;
	}
	stop( "get_line is broken" );
	return( "get_line is broken" );
}

inline bool in( const std::string& elem, const std::map<std::string, std::ofstream*>& x ) {
	if( x.find(elem) == x.end() ) {
		return false;
	} else {
		return true;
	}
}

inline void print_counter( int& counter ) {
	if ( (counter % 100000) == 0 ) {
		Rcout << "i = " << counter << std::endl;
	}
  ++counter;
}

// [[Rcpp::export]]
void split_file(
		std::string path,
		std::string dir,
		std::string basename,
		std::string path_sep,
		std::string sep,
		std::string prepend,
		std::string file_ext,
		int column,
		int skip,
		bool verbose) {

	// space for a line, and a file map
	std::string line;
	std::map< std::string, std::ofstream* > files;
	std::map< std::string, std::ostreambuf_iterator<char>* > file_itrs;
	const char* delim = sep.c_str();

	// input file connections
	std::ifstream conn;
	conn.open( path.c_str(), std::ios_base::binary );

	int counter = 0;

	if( conn.is_open() ) {

		// skip lines
		if( skip > 0 ) {
			for( int i=0; i < skip; ++i ) {
				std::getline( conn, line );
			}
		}

		while( std::getline( conn, line ) ) {

			// check the value of the 'column'th item
			// we copy the string so that strtok doesn't mangle it
			std::string str_copy;
			str_copy = line.c_str();
			std::string col_item = get_item(str_copy, delim, column);

			// if a column entry has not yet been found, open a new file connection
			if( !in( col_item, files ) ) {
				if( verbose ) {
					Rcout << "Opening new file for column entry: " << col_item << std::endl;
				}
				std::string file_path =  dir + path_sep + basename + "_" + prepend + col_item + file_ext;
				files[col_item] = new std::ofstream( file_path.c_str() );
				file_itrs[col_item] = new std::ostreambuf_iterator<char>( *files[col_item] );
			}

			// write the line to the appropriate ofstream
			copy( line.begin(), line.end(), *file_itrs[col_item] );
			*file_itrs[col_item] = '\n';
			// *files[col_item] << line << std::endl;

			// write out the counter?
			if( verbose ) {
				print_counter(counter);
			}

		}

	}

	// close the other file connections
	typedef std::map<std::string, std::ofstream*>::iterator MItr;
	for( MItr it = files.begin(); it != files.end(); ++it ) {
		it->second->close();
		delete it->second;
	}
	files.clear();

	typedef std::map<std::string, std::ostreambuf_iterator<char>*>::iterator NItr;
	for( NItr it = file_itrs.begin(); it != file_itrs.end(); ++it ) {
		delete it->second;
	}
	file_itrs.clear();

}

#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
List split_runs_numeric( NumericVector X ) {

	List out( X.size() );

	std::vector< std::vector< double > > all_nums;
	std::vector< double > curr_nums;

	// initial stuff
	curr_nums.push_back( X[0] );

	for( NumericVector::iterator it = X.begin()+1; it != X.end(); ++it ) {
		if( (*it) != (*(it-1)) ) {
			all_nums.push_back( curr_nums );
			curr_nums.clear();
			curr_nums.push_back( *it );
		} else {
			curr_nums.push_back( *it );
		}
	}

	// push the final vector in
	all_nums.push_back( curr_nums );

	return wrap( all_nums );

}

// [[Rcpp::export]]
List split_runs_character( std::vector< std::string > X ) {

	std::vector< std::vector< std::string > > all_nums;
	std::vector< std::string > curr_nums;

	// initial stuff
	curr_nums.push_back( X[0] );

	for( std::vector< std::string >::iterator it = X.begin() + 1; it != X.end(); ++it ) {
		if( *it != *(it-1) ) {
			all_nums.push_back( curr_nums );
			curr_nums.clear();
			curr_nums.push_back( *it );
		} else {
			curr_nums.push_back( *it );
		}
	}

	// push the final vector in
	all_nums.push_back( curr_nums );

	return wrap( all_nums );

}

// [[Rcpp::export]]
List split_runs_one( std::string x ) {

	std::vector< std::string > out;

	std::string curr_str;
	curr_str.append( x, 0, 1 );

	for( std::string::const_iterator it = x.begin()+1; it != x.end(); ++it ) {
		if( *it != *(it-1) ) {
			out.push_back( curr_str );
			curr_str.erase();
			curr_str.push_back( *it );
		} else {
			curr_str.push_back( *it );
		}
	}

	out.push_back( curr_str );

	return wrap(out);

}

#include <Rcpp.h>
using namespace Rcpp;

template <int RTYPE, class container>
inline
Vector<RTYPE> stack( List& X, int index ) {
	std::vector<container> out;
	int x_size = X.size();
	for( int i=0; i < x_size; ++i ) {
		List tmp = as<List>(X[i]);
		std::vector<container> tmp2 = tmp[index];
		int tmp2_size = tmp2.size();
		for( int j=0; j < tmp2_size; ++j ) {
			out.push_back( tmp2[j] );
		}
	}
	return wrap(out);
}

// [[Rcpp::export]]
List stack_list_df( List& X,
		std::vector< std::string > classes,
		int num_elem,
		bool make_row_names,
		std::string name,
		bool keep_list_index,
		std::string index_name ) {

	List out(num_elem);

	// loop through the columns to generate the stacked DF
	List tmp = as<List>(X[0]);

	for( int i=0; i < num_elem; ++i ) {

		switch( TYPEOF(tmp[i]) ) {
		case STRSXP:
			out[i] = stack<STRSXP, std::string>(X, i);
			break;
		case REALSXP:
			out[i] = stack<REALSXP, double>(X, i);
			break;
		case INTSXP:
			out[i] = stack<INTSXP, int>(X, i);
			break;
		case LGLSXP:
			out[i] = stack<LGLSXP, int>(X, i);
			break;
		case RAWSXP:
			out[i] = stack<RAWSXP, unsigned char>(X, i);
			break;
		}

	}

	// add the list indices as a vector
	if( keep_list_index ) {
		std::vector<int> list_indices;
		int counter = 1;
		for( int i=0; i < X.size(); ++i ) {
			List tmp = as<List>( X[i] );
			for( int j=0; j < ::Rf_length( tmp[0] ); ++j ) {
				list_indices.push_back(counter);
			}
			++counter;
		}
		out["index"] = wrap( list_indices );
	}

	// get row names to assign to vector of df
	if( make_row_names ) {
		std::vector< std::string > row_names;
		for( int i=0; i < X.size(); ++i ) {
			std::vector< std::string > rownames = as<std::vector< std::string > >( as<List>( X[i] ).attr("row.names") );
			int rownames_size = rownames.size();
      for( int j=0; j < rownames_size; ++j ) {
				row_names.push_back( rownames[j] );
			}
		}

		out["which"] = wrap( row_names );
	}

	std::vector<std::string> col_names = as<List>(X[0]).attr("names");

	if( keep_list_index ) {
		col_names.push_back( index_name );
	}

	if( make_row_names ) {
		col_names.push_back( name );
	}

	out.attr("names") = col_names;
	out.attr("class") = "data.frame";
	return out;

}

#include <Rcpp.h>
using namespace Rcpp;

inline void check_type( SEXP x, std::string name ) {
  switch( TYPEOF(x) ) {
    case INTSXP:
    case REALSXP:
    case STRSXP:
      break;
    default:
      Rf_error("Argument '%s' is of incompatible type '%s'", 
        name.c_str(), 
        Rf_type2char( TYPEOF(x) )
      );
  }
}

template <int RTYPE>
Vector<RTYPE> do_swap( const Vector<RTYPE> vec, const Vector<RTYPE>& from, const Vector<RTYPE>& to ) {
  IntegerVector matches = match(vec, from) - 1;
  int n = vec.size();
  Vector<RTYPE> out = no_init(n);
  for( int i=0; i < n; ++i ) {
    // Rcout << "matches[" << i << "] is: " << matches[i] << std::endl;
    if( !IntegerVector::is_na( matches[i] ) ) {
      // Rcout << "\tmatches[" << i << "] is not NA" << std::endl;
      out[i] = to[ matches[i] ];
    } else {
      // Rcout << "\tmatches[" << i << "] is NA" << std::endl;
      out[i] = vec[i];
    }
  }
  return out;
}

// [[Rcpp::export]]
SEXP swap( SEXP vec, SEXP from, SEXP to ) {
  
  check_type(vec, "vec");
  check_type(from, "from");
  check_type(to, "to");
  
  if( TYPEOF(to) > TYPEOF(from) ) {
    from = Rf_coerceVector(from, TYPEOF(to));
  } else if( TYPEOF(from) > TYPEOF(to) ) {
    to = Rf_coerceVector(to, TYPEOF(from));
  }
  
  switch( TYPEOF(to) ) {
    case INTSXP: return do_swap<INTSXP>(vec, from, to);
    case REALSXP: return do_swap<REALSXP>(vec, from, to);
    case STRSXP: return do_swap<STRSXP>(vec, from, to);
    //case LGLSXP: return do_swap<LGLSXP>(x, y);
    default: stop("incompatible RTYPE");
  }
  
  return R_NilValue;
  
}

