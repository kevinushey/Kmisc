library(shiny)

shinyServer( function(input, output, session) {
  
})
