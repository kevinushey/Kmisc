#' Reverse a Vector of Strings
#' 
#' Reverses a vector of 'strings' (a character vector).
#' 
#' This function is written in C for fast execution; however, we do not handle 
#' non-ASCII characters. For a 'safe' version of \code{str_rev} that handles
#' unicode characters, see \code{\link{str_rev2}}.
#' @export
#' @param x a character vector
str_rev <- function(x) {
  tmp <- .Call("str_rev", as.character(x), PACKAGE="Kmisc")
  tmp[ is.na(x) ] <- NA
  return(tmp)
}

#' Reverse a Vector of Strings (UTF-8)
#' 
#' Reverses a vector of 'strings' (a character vector).
#' 
#' This function will handle UTF-8 characters safely, but is rather slow. If you
#' are working only with ASCII characters and require speed, see \code{\link{str_rev2}}.
#' 
#' @export
#' @param x a character vector
#' @examples
#' str_rev2("はろー！")
str_rev2 <- function(x) {
  sapply( as.character(x), USE.NAMES=FALSE, function(xx) {
    intToUtf8( rev( utf8ToInt( xx ) ) )
  })
}